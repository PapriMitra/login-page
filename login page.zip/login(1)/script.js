const signInBtnLink=document.querySelector('.signInBtn-link');
const registerBtnLink=document.querySelector('.registerBtn-link');
const wrapper=document.querySelector('.wrapper');

registerBtnLink.addEventListener('click',()=>{
    wrapper.classList.toggle('active');
});
signInBtnLink.addEventListener('click',()=>{
    wrapper.classList.toggle('active');
});